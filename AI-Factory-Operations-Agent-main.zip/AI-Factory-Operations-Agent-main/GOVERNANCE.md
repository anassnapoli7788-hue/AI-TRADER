# Governance

AI Factory Operations Agent is maintained by NVIDIA. Maintainers listed in [MAINTAINERS.md](MAINTAINERS.md) review contributions, manage releases, and make final decisions about project scope.

Project changes are proposed through GitHub issues and pull requests. Maintainers seek consensus through technical review. When consensus is not reached, the maintainers decide based on project goals, security, maintainability, and compatibility.

Changes require maintainer approval and successful required checks before merge. Security-sensitive discussions follow [SECURITY.md](SECURITY.md).

Before merging or distributing modifications, maintainers must complete the project [IP review process](IP_REVIEW.md). External contributions must also satisfy the [Developer Certificate of Origin](DCO.md).

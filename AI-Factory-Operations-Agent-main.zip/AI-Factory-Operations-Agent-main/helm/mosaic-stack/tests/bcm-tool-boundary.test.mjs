// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const plugin = readFileSync(
  new URL("../files/openclaw-seed/extensions/bcm/index.ts", import.meta.url),
  "utf8",
);
const adapter = readFileSync(new URL("../files/bcm-mcp-ssh-server.py", import.meta.url), "utf8");

test("runs BCM tools locally and sends command execution over SSH", () => {
  assert.match(adapter, /from bcm_mcp_tools\.server import BCMServer/);
  assert.doesNotMatch(adapter, /SSHTunnelManager|install_server|bcm-mcp-tools-install/);
  assert.match(plugin, /context\.ssh_host = config\.headHost/);
  assert.doesNotMatch(plugin, /hostname: config\.headHost/);
});

test("does not permit BCM configuration to disable TLS verification", () => {
  const manifest = JSON.parse(readFileSync(
    new URL("../files/openclaw-seed/extensions/bcm/openclaw.plugin.json", import.meta.url),
  ));
  assert.equal(manifest.configSchema.properties.allowInsecureTls, undefined);
  assert.equal(manifest.uiHints.allowInsecureTls, undefined);
  assert.doesNotMatch(plugin, /NODE_TLS_REJECT_UNAUTHORIZED|allowInsecureTls/);
});

test("keeps readonly and admin CMSH on separate tools and identities", () => {
  assert.match(plugin, /name: "bcm_execute_cmsh"[\s\S]*?"execute_cmsh"/);
  assert.match(plugin, /name: "bcm_execute_cmsh_admin"[\s\S]*?"execute_cmsh_admin"/);
  assert.match(plugin, /if \(config\.editEnabled && config\.cmshEnabled\) registerTool/);
  assert.doesNotMatch(plugin, /classifyCmshRequest/);
  assert.doesNotMatch(plugin, /request\.mutating/);
});

test("requires approval for BCM mutation tools", () => {
  const start = plugin.indexOf("api.registerTrustedToolPolicy");
  const hook = plugin.slice(start, plugin.indexOf("registerTool({", start));
  assert.match(hook, /bcm_add_note.*bcm_execute_cmsh_admin.*bcm_remove_note/s);
  assert.match(hook, /requireApproval:/);
  assert.match(hook, /timeoutBehavior: "deny"/);
  assert.doesNotMatch(hook, /bcm_execute_cmsh"/);
});

test("uses per-session Auto to skip BCM approvals without weakening automation", () => {
  assert.match(plugin, /contextSkipsApproval\(context\)/);
  assert.match(plugin, /requestIdentityApproval\(context, approval\)/);
  assert.match(plugin, /isReadonlyAutomationSession\(context\.sessionKey\)/);
});

test("retains the authenticated admin backend without readonly fallback", () => {
  assert.match(adapter, /def _run_cmsh_admin/);
  assert.match(adapter, /MOSAIC_BCM_CMSH_ADMIN_ENABLED/);
  assert.match(adapter, /StaticTokenVerifier/);
  assert.doesNotMatch(adapter, /_run_cmsh_admin[\s\S]*?su\s+-/);
});

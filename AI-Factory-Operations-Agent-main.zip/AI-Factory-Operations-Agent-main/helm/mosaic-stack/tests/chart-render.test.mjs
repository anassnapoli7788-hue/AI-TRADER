// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

import assert from "node:assert/strict";
import { execFileSync, spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync, readdirSync, existsSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";

const chart = fileURLToPath(new URL("..", import.meta.url));
const slackManifest = fileURLToPath(new URL("../profiles/slack-app-manifest.json", import.meta.url));
const slackEnterprisePatch = fileURLToPath(
  new URL("../files/openclaw-seed/slack-enterprise-grid-patch.mjs", import.meta.url),
);

function configMapBlock(output, key) {
  const lines = output.split("\n");
  const start = lines.findIndex(line => line.startsWith(`  ${key}: |`));
  assert.ok(start >= 0, `Missing ConfigMap entry: ${key}`);
  const body = [];
  for (const line of lines.slice(start + 1)) {
    if (line && !line.startsWith("    ")) break;
    body.push(line.slice(4));
  }
  return body.join("\n");
}

test("startup-loads the Kubernetes approval hook", () => {
  const manifest = JSON.parse(
    readFileSync(new URL("../files/openclaw-seed/extensions/kubernetes/openclaw.plugin.json", import.meta.url)),
  );
  assert.equal(manifest.activation?.onStartup, true);
  assert.deepEqual(manifest.contracts?.trustedToolPolicies, ["kubernetes-access"]);
});

test("startup-loads one shared diagnostic policy", () => {
  const seed = render("--show-only", "templates/openclaw-seed-configmap.yaml");
  const runtime = render("--show-only", "templates/openclaw.yaml");
  assert.match(seed, /diagnostic-policy\.ts/);
  assert.match(runtime, /cp \/seed\/diagnostic-policy\.ts \/home\/node\/\.openclaw\/extensions\/diagnostic-policy\.ts/);
});

test("startup removes managed plugins before applying the enabled module set", () => {
  const runtime = render("--show-only", "templates/openclaw.yaml");
  for (const name of ["bcm", "diagnostic-agent", "grafana", "iraop", "kubernetes", "observability", "remote-ssh", "slurm"]) {
    assert.match(runtime, new RegExp(`/home/node/\\.openclaw/extensions/${name}`));
  }
});

test("startup-loads the remote SSH approval hook", () => {
  const manifest = JSON.parse(
    readFileSync(new URL("../files/openclaw-seed/extensions/remote-ssh/openclaw.plugin.json", import.meta.url)),
  );
  assert.equal(manifest.activation?.onStartup, true);
  assert.deepEqual(manifest.contracts?.trustedToolPolicies, ["remote-ssh-access"]);
});

test("startup-loads the automation read-only guard", () => {
  const manifest = JSON.parse(
    readFileSync(new URL("../files/openclaw-seed/extensions/automation-guard/openclaw.plugin.json", import.meta.url)),
  );
  assert.equal(manifest.activation?.onStartup, true);
  assert.deepEqual(manifest.contracts?.trustedToolPolicies, ["session-access"]);
  const seed = render("--show-only", "templates/openclaw-seed-configmap.yaml");
  assert.match(seed, /"automation-guard":\s*{\s*"enabled": true,\s*"hooks":\s*{\s*"allowConversationAccess": true\s*},\s*"config":\s*{\s*"editEnabled": false/);
  assert.match(render("--set", "modules.edit.enabled=true", "--show-only", "templates/openclaw-seed-configmap.yaml"), /"editEnabled": true/);
  assert.match(seed, /automation-context\.ts: \|-/);
  assert.match(seed, /"hitl": true,[\s\S]*"approvalTimeoutMs": 120000/);
  const runtime = render("--show-only", "templates/openclaw.yaml");
  assert.match(runtime, /cp \/seed\/automation-guard\.index\.ts/);
  assert.doesNotMatch(runtime, /cp \/seed\/(?:bcm|kubernetes)-policy\.ts/);
});

function render(...args) {
  return execFileSync("helm", ["template", "mosaic", chart, "--namespace", "mosaic-test", ...args], {
    encoding: "utf8",
  });
}

function renderDiagnostics(...args) {
  return render(
    "--set", "modules.diagnostics.enabled=true",
    "--set", "bcmMcp.enabled=true",
    "--set", "bcmMcp.mode=ssh-adapter",
    "--set", "bcmMcp.headHost=bcm-head.example.com",
    "--set", "bcmMcp.hostSshKeySecretName=bcm-host-ssh-key",
    ...args,
  );
}

test("preserves memory maintenance with embedding-free indexed recall", () => {
  const seed = render("--show-only", "templates/openclaw-seed-configmap.yaml");
  assert.match(seed, /"memorySearch":\s*\{\s*"provider": "none"/);
  assert.match(seed, /"vector":\s*\{\s*"enabled": false/);
  assert.doesNotMatch(seed, /"slots":\s*\{\s*"memory": "none"/);
  assert.match(seed, /Use connected operational systems as the source of truth/);
});

test("native memory indexes Markdown and preserves appended notes across restarts", {
  skip: !process.env.OPENCLAW_RUNTIME_ROOT,
}, () => {
  const directory = mkdtempSync(join(tmpdir(), "mosaic-memory-test-"));
  try {
    const result = spawnSync(process.execPath, ["--input-type=module", "-e", `
      import assert from "node:assert/strict";
      import fs from "node:fs";
      import path from "node:path";
      import { pathToFileURL } from "node:url";
      let networkCalls = 0;
      globalThis.fetch = async () => {
        networkCalls += 1;
        throw new Error("Network is unavailable in this test");
      };
      const { MemoryIndexManager } = await import(pathToFileURL(path.join(
        process.env.OPENCLAW_RUNTIME_ROOT, "dist/extensions/memory-core/manager-runtime.js",
      )));
      const workspace = path.join(process.env.OPENCLAW_STATE_DIR, "workspace");
      fs.mkdirSync(path.join(workspace, "memory"), { recursive: true });
      const file = path.join(workspace, "memory", "2026-01-01.md");
      const entries = [
        { text: "The storage maintenance window starts Tuesday.", query: "storage maintenance" },
        { text: "The fabric inspection is scheduled Friday.", query: "fabric inspection" },
      ];
      fs.writeFileSync(file, entries[0].text + "\\n");
      const cfg = { agents: {
        defaults: { workspace, memorySearch: {
          provider: "none", store: { vector: { enabled: false } },
          sync: { onSessionStart: false, watch: false },
        } },
        list: [{ id: "test", workspace }],
      } };
      let manager = await MemoryIndexManager.get({ cfg, agentId: "test", purpose: "cli" });
      try {
        assert.ok((await manager.search(entries[0].query)).some(hit => hit.snippet.includes(entries[0].text)));
        fs.appendFileSync(file, entries[1].text + "\\n");
        await manager.sync({ force: true, reason: "cli" });
        await manager.close();
        manager = await MemoryIndexManager.get({ cfg, agentId: "test", purpose: "cli" });
        for (const entry of entries) {
          assert.ok((await manager.search(entry.query)).some(hit => hit.snippet.includes(entry.text)));
        }
        assert.equal(networkCalls, 0);
      } finally {
        await manager.close();
      }
    `], {
      encoding: "utf8",
      timeout: 60000,
      env: {
        PATH: process.env.PATH,
        HOME: directory,
        OPENCLAW_STATE_DIR: directory,
        OPENCLAW_CONFIG_PATH: join(directory, "openclaw.json"),
        OPENCLAW_RUNTIME_ROOT: process.env.OPENCLAW_RUNTIME_ROOT,
      },
    });
    assert.equal(result.status, 0, result.stderr);
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});

test("generates one internal Hardware Agent credential for the service and OpenClaw", () => {
  const output = renderDiagnostics();
  const apiKey = output.match(/name: diagnostic-agent-auth[\s\S]*?API_KEY: "([A-Za-z0-9]{48})"/);
  const apiKeys = output.match(/AGENT_API_KEYS: "\{\\"openclaw\\":\\"([A-Za-z0-9]{48})\\"\}"/);
  const bcmKey = output.match(/BCM_WEBHOOK_TOKEN: "([A-Za-z0-9]{48})"/);
  assert.equal(apiKeys?.[1], apiKey?.[1]);
  assert.ok(bcmKey?.[1]);
  assert.equal((output.match(/kind: Secret\s+metadata:\s+name: diagnostic-agent-auth/g) || []).length, 1);
  assert.match(output, /name: DIAGNOSTIC_AGENT_API_KEY\s+valueFrom:\s+secretKeyRef:\s+name: diagnostic-agent-auth\s+key: API_KEY/);
  assert.match(output, /name: DIAGNOSTIC_AGENT_AUTH_MODE\s+value: required/);
  assert.doesNotMatch(output, /name: diagnostic-agent-api-keys|name: diagnostic-agent-secrets/);
});

test("preserves the secured Hardware Agent image entrypoint", () => {
  const output = renderDiagnostics("--show-only", "templates/diagnostic-agent.yaml");
  assert.match(output, /name: diagnostic-agent\s+image:[\s\S]*?args: \["--host", "0\.0\.0\.0", "--port", "8080"\]/);
  assert.doesNotMatch(output, /command: \["diagnostic-agent"/);
});

test("wires Hardware Agent BCM lookup through the internal SSH adapter", () => {
  const output = renderDiagnostics();
  assert.match(output, /name: MOSAIC_BCM_HEAD_HOST\s+value: "bcm-head\.example\.com"/);
  assert.match(output, /name: MOSAIC_BCM_HARDWARE_COMPAT_ENABLED\s+value: "true"/);
  assert.match(output, /name: MOSAIC_BCM_HARDWARE_TOKEN\s+valueFrom:\s+secretKeyRef:\s+name: diagnostic-agent-auth\s+key: BCM_WEBHOOK_TOKEN/);
  assert.match(output, /name: BCM_WEBHOOK_URL\s+value: "http:\/\/bcm-mcp-tools:3001"/);
  assert.match(output, /name: BCM_WEBHOOK_TOKEN\s+valueFrom:\s+secretKeyRef:\s+name: diagnostic-agent-auth\s+key: BCM_WEBHOOK_TOKEN/);
  assert.doesNotMatch(output, /bcm-webhook-creds/);
  assert.doesNotMatch(output, /name: DEBUGHUB_BCM__WEBHOOK_(?:URL|TOKEN)/);
});

test("applies global scheduling controls to the Hardware Agent", () => {
  const output = renderDiagnostics(
    "--set-json", 'global.nodeSelector={"kubernetes.io/hostname":"worker-02"}',
    "--set-json", 'global.tolerations=[{"key":"dedicated","operator":"Exists"}]',
    "--show-only", "templates/diagnostic-agent.yaml",
  );
  assert.match(output, /nodeSelector:\s+kubernetes\.io\/hostname: worker-02/);
  assert.match(output, /tolerations:\s+- key: dedicated\s+operator: Exists/);
});

test("requires the BCM SSH adapter for Hardware Agent installs", () => {
  for (const [settings, expected] of [
    [[], /requires bcmMcp\.enabled=true/],
    [["bcmMcp.enabled=true"], /requires bcmMcp\.mode=ssh-adapter/],
  ]) {
    const args = ["template", "mosaic", chart, "--namespace", "mosaic-test", "--set", "modules.diagnostics.enabled=true"];
    for (const setting of settings) args.push("--set", setting);
    const result = spawnSync("helm", args, { encoding: "utf8" });
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, expected);
  }
});

test("renders only official OpenClaw and OpenShell runtime images", () => {
  const output = render();
  for (const image of [
    "ghcr.io/openclaw/openclaw:2026.6.10",
    "ghcr.io/nvidia/openshell/gateway:0.0.75",
    "ghcr.io/nvidia/openshell/supervisor:0.0.75",
    "ghcr.io/nvidia/openshell-community/sandboxes/base@sha256:aeef1c63f00e2913ea002ccb3aaf925f338b5c5d70e63576f0d95c16a138044e",
  ]) {
    assert.ok(output.includes(image), "missing image " + image);
  }
  assert.doesNotMatch(output, /nvcr\.io\/[^\s"']*\/(?:nemoclaw|openshell)/);
  assert.doesNotMatch(output, /privileged:\s*true/);
  assert.doesNotMatch(output, /nvidia-openshell|backend["']?:\s*["']nemoclaw/);
});

test("pins every default runtime image", () => {
  const output = render();
  assert.ok(
    output.includes(
      "vllm/vllm-openai@sha256:cb9bc64f0f038c2c2ebf13b31248fb87aca40c356c3d20f363be087cfcff1fcd",
    ),
  );
  assert.doesNotMatch(output, /image:\s*["']?\S+:latest(?:["']|\s|$)/);
});

test("renders namespace labeling with the configured kubectl image", () => {
  const output = render(
    "--show-only",
    "templates/namespace-labels.yaml",
    "--set-json",
    'namespace.labels={"example.com/managed":"true"}',
  );
  assert.match(output, /image: "registry\.k8s\.io\/kubectl:v1\.30\.0"/);
  assert.match(output, /"example\.com\/managed=true"/);
});

test("pins the UI to an immutable commit tag", () => {
  const output = render("--show-only", "templates/mosaic-ui.yaml");
  assert.match(output, /image: "[^"\s]+\/mosaic-ui:[0-9a-f]{8}"/);
});

test("protects the UI with a generated login", () => {
  const output = render();
  assert.match(output, /name: mosaic-ui-auth[\s\S]*username: "operator"[\s\S]*password: "[A-Za-z0-9]{32}"/);
  assert.match(output, /name: MOSAIC_UI_USERNAME\s+valueFrom:/);
  assert.match(output, /path: \/api\/health/);
});

test("authenticates internal UI callbacks with one machine credential", () => {
  const secret = render("--show-only", "templates/mosaic-ui-auth-secret.yaml");
  assert.match(secret, /machineToken: "[A-Za-z0-9]{48}"/);

  for (const template of ["templates/mosaic-ui.yaml", "templates/openclaw.yaml"]) {
    const output = render("--show-only", template);
    assert.match(
      output,
      /name: MOSAIC_UI_MACHINE_TOKEN\s+valueFrom:\s+secretKeyRef:\s+name: mosaic-ui-auth\s+key: machineToken/,
    );
  }

  for (const [path, expectedCallbacks] of [
    ["../files/openclaw-seed/extensions/bcm/index.ts", 1],
    ["../files/openclaw-seed/extensions/diagnostic-agent/index.ts", 1],
    ["../files/openclaw-seed/extensions/grafana/index.ts", 2],
    ["../files/openclaw-seed/extensions/iraop/index.ts", 1],
    ["../files/openclaw-seed/extensions/observability/grafana.ts", 2],
  ]) {
    const plugin = readFileSync(new URL(path, import.meta.url), "utf8");
    assert.match(plugin, /Authorization: `Bearer \$\{token\}`/);
    assert.equal((plugin.match(/headers: uiAuthHeaders\(\)/g) || []).length, expectedCallbacks);
    if (path.endsWith("grafana.ts") || path.endsWith("grafana/index.ts")) {
      assert.match(
        plugin,
        /`\$\{uiUrl\}\/api\/grafana\/proxy\/api\/ds\/query`[\s\S]*?headers: \{ \.\.\.uiAuthHeaders\(\), Origin: uiUrl \}/,
      );
    }
  }
});

test("uses an existing UI auth secret for browser and machine credentials", () => {
  for (const template of ["templates/mosaic-ui.yaml", "templates/openclaw.yaml"]) {
    const output = render(
      "--set", "mosaicUi.auth.create=false",
      "--set", "mosaicUi.auth.existingSecret=shared-ui-auth",
      "--show-only", template,
    );
    assert.match(
      output,
      /name: MOSAIC_UI_MACHINE_TOKEN\s+valueFrom:\s+secretKeyRef:\s+name: shared-ui-auth\s+key: machineToken/,
    );
  }
});

test("seeds BCM manuals without deployment-time network access", () => {
  const output = renderDiagnostics(
    "--set-string", "mosaicUi.image.tag=1234abcd",
    "--show-only", "templates/openclaw.yaml",
  );
  const init = output.split("- name: init-bcm-docs")[1]?.split("- name: install-openshell-assets")[0] || "";
  assert.match(init, /image: "[^"\s]+\/mosaic-ui:1234abcd"/);
  assert.match(init, /tar -xzf \/opt\/nemoclaw\/bcm-docs\.tar\.gz/);
  assert.doesNotMatch(init, /https?:|curl|apk|python|pdftotext/);
  assert.doesNotMatch(renderDiagnostics("--show-only", "templates/openclaw-seed-configmap.yaml"), /bcm-docs-download/);
  assert.doesNotMatch(
    render("--set", "modules.bcm.enabled=false", "--show-only", "templates/openclaw.yaml"),
    /name: init-bcm-docs/,
  );
});

test("uses NMC observability services by default", () => {
  const output = render();
  assert.match(output, /http:\/\/kube-prometheus-stack-prometheus\.prometheus\.svc\.cluster\.local:9090/);
  assert.match(output, /http:\/\/kube-prometheus-stack-grafana\.prometheus\.svc\.cluster\.local\/grafana/);
  assert.match(output, /"datasourceUid": "prometheus"/);
  assert.doesNotMatch(output, /mosaic-observability/);
});

test("configures the Alertmanager endpoint", () => {
  const defaultOutput = render("--show-only", "templates/mosaic-ui.yaml");
  assert.match(
    defaultOutput,
    /name: MOSAIC_ALERTMANAGER_URL\s+value: "http:\/\/kube-prometheus-stack-alertmanager\.prometheus\.svc\.cluster\.local:9093"/,
  );

  const customOutput = render(
    "--set-string",
    "observability.alertmanagerUrl=https://alerts.example.com/alertmanager",
    "--show-only",
    "templates/mosaic-ui.yaml",
  );
  assert.match(
    customOutput,
    /name: MOSAIC_ALERTMANAGER_URL\s+value: "https:\/\/alerts\.example\.com\/alertmanager"/,
  );
});

test("shares the managed Research Agent corpus with the UI", () => {
  const output = render(
    "--show-only", "templates/mosaic-ui.yaml",
    "--set", "modules.research.enabled=true",
    "--set", "researchAgent.iraop.config.CORPUS_DIR=/data/corpus",
    "--set", "researchAgent.iraop.corpus.hostPath=/srv/corpus",
  );
  assert.match(output, /name: MOSAIC_IRAOP_CORPUS_DIR\s+value: "\/data\/corpus"/);
  assert.match(output, /name: MOSAIC_IRAOP_BASE_URL\s+value: "http:\/\/iraop:8000"/);
  assert.match(output, /name: MOSAIC_IRAOP_API_KEY\s+valueFrom:\s+secretKeyRef:\s+name: iraop-secrets\s+key: IRAOP_API_KEY/);
  assert.match(output, /name: research-corpus\s+mountPath: \/data\/corpus/);
  assert.match(output, /name: research-corpus\s+hostPath:\s+path: \/srv\/corpus\s+type: Directory/);
});

test("shares the managed Research Agent credential with OpenClaw", () => {
  const output = render(
    "--set", "modules.research.enabled=true",
    "--show-only", "templates/openclaw.yaml",
  );
  assert.match(output, /name: IRAOP_API_KEY\s+valueFrom:\s+secretKeyRef:\s+name: iraop-secrets\s+key: IRAOP_API_KEY/);
  assert.doesNotMatch(output, /key: IRAOP_API_KEY\s+optional: true/);
});

test("generates a bearer credential with a chart-managed Research Agent Secret", () => {
  const output = render(
    "--set", "modules.research.enabled=true",
    "--set", "modules.research.secrets.create=true",
    "--set", "modules.research.secrets.nvidiaApiKey=test-key",
    "--show-only", "templates/secrets.yaml",
  );
  assert.match(output, /name: iraop-secrets[\s\S]*IRAOP_API_KEY: "[A-Za-z0-9]{48}"/);
});

test("uses one no-reasoning request contract for external endpoints", () => {
  const output = render(
    "--set", "llm.mode=external",
    "--set", "llm.external.baseUrl=https://inference.example/v1",
    "--set", "llm.external.model=example-model",
    "--show-only", "templates/llm-compat.yaml",
  );
  assert.match(output, /json\.reasoning_effort = 'none'/);
  assert.doesNotMatch(output, /DISABLE_THINKING|VLLM_UPSTREAM|chat_template_kwargs|scrubVisibleThinking|pipeOpenAiStream/);
});

test("configures chart-managed vLLM for non-thinking generation", () => {
  for (const args of [
    [],
    ["--values", join(chart, "profiles/vllm-super-1gpu.yaml")],
    ["--values", join(chart, "profiles/vllm-ultra-4gpu.yaml")],
  ]) {
    const output = render(...args, "--show-only", "templates/vllm.yaml");
    assert.match(output, /--default-chat-template-kwargs=\{\\?"enable_thinking\\?":false\}/);
  }
});

test("defaults to a single Super inference pod with one GPU", () => {
  const output = render("--show-only", "templates/vllm.yaml");
  assert.equal((output.match(/kind: StatefulSet/g) ?? []).length, 1);
  assert.match(output, /NVIDIA-Nemotron-3.5-Super-VL-120B-A12B-NVFP4/);
  assert.match(output, /--tensor-parallel-size=1/);
  assert.equal((output.match(/nvidia.com\/gpu: "1"/g) ?? []).length, 2);
  assert.match(output, /memory: 64Gi/);
  assert.match(output, /storage: 500Gi/);
  assert.doesNotMatch(output, /ray-worker|ray-head|RAY_ADDRESS/);
});

test("the Ultra profile uses four GPUs in a single inference pod", () => {
  const output = render("--values", join(chart, "profiles/vllm-ultra-4gpu.yaml"), "--show-only", "templates/vllm.yaml");
  assert.equal((output.match(/kind: StatefulSet/g) ?? []).length, 1);
  assert.match(output, /NVIDIA-Nemotron-3-Ultra-550B-A55B-NVFP4/);
  assert.match(output, /--tensor-parallel-size=4/);
  assert.equal((output.match(/nvidia.com\/gpu: "4"/g) ?? []).length, 2);
  assert.doesNotMatch(output, /ray-worker|ray-head|RAY_ADDRESS/);
});

test("rejects removed distributed inference and mismatched GPU allocation", () => {
  for (const [setting, message] of [
    ["llm.vllm.profile=ultra-16gpu", /profile must be one of/],
    ["llm.vllm.distributed.enabled=true", /distributed has been removed/],
    ["llm.vllm.gpuCount=2", /tensorParallelSize must equal/],
  ]) {
    const result = spawnSync("helm", ["template", "mosaic", chart, "--set", setting], { encoding: "utf8" });
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, message);
  }
});

test("renders the OpenShell backend with mTLS under XDG_CONFIG_HOME", () => {
  const output = render();
  assert.match(output, /"backend": "openshell"/);
  assert.match(output, /name: openshell-client-tls/);
  assert.match(
    output,
    /mountPath: \/home\/node\/\.openclaw\/\.config\/openshell\/gateways\/mosaic-openshell\/mtls/,
  );
  assert.match(output, /value: "https:\/\/mosaic-openshell:8080"/);
});

test("installs the verified OpenShell package through OpenClaw", () => {
  const output = render("--show-only", "templates/openclaw.yaml");
  assert.match(output, /node \/app\/dist\/index\.js plugins install \/openshell-plugin --force/);
  assert.doesNotMatch(output, /cp -R "\$package"\/\./);
});

test("does not render Slack runtime behavior when disabled", () => {
  const output = render();
  assert.doesNotMatch(output, /"maxConcurrent": 8/);
  assert.doesNotMatch(output, /"dmScope": "per-channel-peer"/);
  assert.doesNotMatch(output, /"stuckSessionWarnMs": 60000/);
  assert.doesNotMatch(output, /slack-enterprise-grid-patch\.mjs/);
  assert.doesNotMatch(output, /init-slack-plugin|SLACK_(?:BOT|APP)_TOKEN/);
  assert.match(output, /"slackEnabled": false/);
  assert.match(output, /"slackEditUserIds": \[\]/);
});

test("renders native Slack Socket Mode with isolated execution", () => {
  const output = render(
    "--set",
    "openclaw.slack.enabled=true",
    "--set",
    "openclaw.slack.existingSecret=mosaic-slack",
    "--set",
    "openclaw.slack.allowedUserIds[0]=U12345678",
  );
  assert.match(output, /"backend": "openshell"/);
  assert.match(output, /"mode": "socket"/);
  assert.match(output, /"dmPolicy": "allowlist"/);
  assert.match(output, /"allowFrom": \["U12345678"\]/);
  assert.match(output, /"slackEnabled": true/);
  assert.match(output, /"slackEditUserIds": \[\]/);
  assert.match(output, /"groupEnabled": false/);
  assert.match(output, /"replyToModeByChatType": \{"channel":"off","direct":"off","group":"off"\}/);
  assert.match(output, /"streaming": \{"mode":"partial","nativeTransport":true\}/);
  assert.match(output, /"maxConcurrent": 8/);
  assert.match(output, /"dmScope": "per-channel-peer"/);
  assert.match(output, /"stuckSessionAbortMs": 150000/);
  assert.match(output, /"byChannel": \{\s*"slack": "followup"/);
  assert.match(output, /name: init-slack-plugin[\s\S]*@openclaw\/slack@2026\.6\.6.*--force/);
  assert.match(output, /node \/seed\/slack-enterprise-grid-patch\.mjs/);
  assert.match(output, /name: "mosaic-slack"[\s\S]*key: "SLACK_BOT_TOKEN"/);
  assert.match(output, /name: "mosaic-slack"[\s\S]*key: "SLACK_APP_TOKEN"/);
  assert.doesNotMatch(output, /xox[baprs]-|xapp-/);
});

test("restricts Slack channel mentions to approved users", () => {
  const output = render(
    "--set",
    "openclaw.slack.enabled=true",
    "--set",
    "openclaw.slack.existingSecret=mosaic-slack",
    "--set",
    "openclaw.slack.allowedUserIds[0]=U12345678",
    "--set",
    "openclaw.slack.channelMentionsEnabled=true",
  );
  assert.match(output, /"groupPolicy": "allowlist"/);
  assert.match(output, /"\*": \{\s*"enabled": true,\s*"requireMention": true,\s*"users": \["U12345678"\]/);
});

test("configures Slack group DMs, replies, and streaming", () => {
  const output = render(
    "--set",
    "openclaw.slack.enabled=true",
    "--set",
    "openclaw.slack.existingSecret=mosaic-slack",
    "--set",
    "openclaw.slack.allowedUserIds[0]=U12345678",
    "--set",
    "openclaw.slack.groupDmsEnabled=true",
    "--set",
    "openclaw.slack.replyToModeByChatType.direct=all",
    "--set",
    "openclaw.slack.replyToModeByChatType.group=all",
    "--set",
    "openclaw.slack.replyToModeByChatType.channel=all",
    "--set-string",
    "openclaw.slack.streaming.mode=off",
    "--set",
    "openclaw.slack.streaming.nativeTransport=false",
  );
  assert.match(output, /"groupEnabled": true/);
  assert.match(output, /"replyToModeByChatType": \{"channel":"all","direct":"all","group":"all"\}/);
  assert.match(output, /"streaming": \{"mode":"off","nativeTransport":false\}/);
});

test("rejects incomplete native Slack configuration", () => {
  for (const args of [
    ["--set", "openclaw.slack.enabled=true"],
    [
      "--set",
      "openclaw.slack.enabled=true",
      "--set",
      "openclaw.slack.existingSecret=mosaic-slack",
    ],
  ]) {
    const result = spawnSync(
      "helm",
      ["template", "mosaic", chart, "--namespace", "mosaic-test", ...args],
      { encoding: "utf8" },
    );
    assert.notEqual(result.status, 0);
  }
});

test("provides a Slack app manifest for approved DMs and mentions", () => {
  const manifest = JSON.parse(readFileSync(slackManifest, "utf8"));
  assert.equal(manifest.display_information.name, "mosaic");
  assert.equal(manifest.features.bot_user.display_name, "mosaic");
  assert.match(manifest.display_information.description, /approved users/);
  assert.match(manifest.display_information.description, /Contact .+ for access/);
  assert.deepEqual(manifest.oauth_config.scopes.bot, [
    "app_mentions:read",
    "channels:history",
    "chat:write",
    "groups:history",
    "im:history",
    "im:read",
    "im:write",
    "mpim:history",
    "mpim:read",
    "mpim:write",
  ]);
  assert.deepEqual(manifest.settings.event_subscriptions.bot_events, [
    "app_mention",
    "message.im",
    "message.mpim",
  ]);
  assert.equal(manifest.settings.socket_mode_enabled, true);
  assert.equal(manifest.features.app_home.home_tab_enabled, false);
  assert.equal(manifest.oauth_config.redirect_urls, undefined);
  assert.deepEqual(manifest.settings.interactivity, { is_enabled: true });
});

test("keeps Slack messaging access broad while granting Edit to explicit identities", () => {
  const output = render(
    "--set", "modules.ui.enabled=false",
    "--set", "modules.edit.enabled=true",
    "--set", "openclaw.slack.enabled=true",
    "--set", "openclaw.slack.existingSecret=mosaic-slack",
    "--set", "openclaw.slack.allowedUserIds[0]=U11111111",
    "--set", "openclaw.slack.allowedUserIds[1]=U22222222",
    "--set", "openclaw.slack.editUserIds[0]=U22222222",
    "--set", "openclaw.slack.channelMentionsEnabled=true",
    "--set", "openclaw.slack.groupDmsEnabled=true",
  );
  assert.match(output, /"allowFrom": \["U11111111","U22222222"\]/);
  assert.match(output, /"execApprovals":\s*{\s*"enabled": true,\s*"approvers": \["U22222222"\],\s*"target": "dm"/);
  assert.match(output, /"users": \["U11111111","U22222222"\]/);
  assert.match(output, /"groupEnabled": true/);
  assert.match(output, /"slackEditUserIds": \["U22222222"\]/);
});

test("omits Slack identity and exec approval configuration when Slack is disabled", () => {
  const output = render();
  assert.doesNotMatch(output, /"channels":\s*{\s*"slack"/);
  assert.doesNotMatch(output, /"execApprovals"/);
  assert.match(output, /"slackEnabled": false/);
  assert.match(output, /"slackEditUserIds": \[\]/);
});

test("validates Slack edit identities without weakening the messaging allowlist", () => {
  for (const settings of [
    ["openclaw.slack.editUserIds[0]=U22222222"],
    [
      "modules.edit.enabled=true",
      "openclaw.slack.enabled=true",
      "openclaw.slack.existingSecret=mosaic-slack",
      "openclaw.slack.allowedUserIds[0]=U11111111",
      "openclaw.slack.editUserIds[0]=U22222222",
    ],
  ]) {
    const args = ["template", "mosaic", chart, "--namespace", "mosaic-test"];
    for (const setting of settings) args.push("--set", setting);
    const result = spawnSync("helm", args, { encoding: "utf8" });
    assert.notEqual(result.status, 0, settings.join(", "));
  }
});

test("patches Slack Enterprise Grid workspace events without weakening app checks", () => {
  const dir = mkdtempSync(join(tmpdir(), "mosaic-slack-patch-"));
  const provider = join(dir, "provider.js");
  writeFileSync(
    provider,
    `\t\tconst incomingTeamId = typeof raw.team_id === "string" ? raw.team_id : typeof raw.team?.id === "string" ? raw.team.id : "";\n` +
    `\t\tif (params.apiAppId && incomingApiAppId && incomingApiAppId !== params.apiAppId) {}\n` +
    `\t\tif (params.teamId && incomingTeamId && incomingTeamId !== params.teamId) {}`,
  );
  execFileSync("node", [slackEnterprisePatch, provider]);
  execFileSync("node", [slackEnterprisePatch, provider]);
  const patched = readFileSync(provider, "utf8");
  rmSync(dir, { recursive: true });
  assert.match(patched, /incomingEnterpriseId/);
  assert.match(patched, /incomingEnterpriseId !== params\.teamId/);
  assert.match(patched, /incomingApiAppId !== params\.apiAppId/);
});

test("exposes only blueprint-owned skills to OpenClaw agents", () => {
  const output = render("--show-only", "templates/openclaw-seed-configmap.yaml");
  const config = JSON.parse(configMapBlock(output, "openclaw.json"));
  const skills = config.agents.defaults.skills;
  assert.ok(skills.includes("gpu-networking"));
  for (const skill of skills) {
    assert.ok(readFileSync(new URL(`../files/openclaw-seed/skills/${skill}/SKILL.md`, import.meta.url)).length);
  }
  assert.equal(config.skills?.allowBundled, undefined);
});

test("renders named external Kubernetes clusters from Secrets", () => {
  const output = render(
    "--set",
    "kubernetes.clusters[0].name=remote",
    "--set",
    "kubernetes.clusters[0].kubeconfigSecretRef.name=remote-kubeconfig",
    "--set",
    "kubernetes.clusters[0].kubeconfigSecretRef.key=config",
    "--set",
    "kubernetes.clusters[0].server=https://bcm-head.example.com:11443",
    "--set",
    "kubernetes.clusters[0].tlsServerName=127.0.0.1",
  );
  assert.ok(output.includes("name: kubernetes-external-0"));
  assert.ok(output.includes('secretName: "remote-kubeconfig"'));
  assert.match(output, /"remote":\{[^}]*"kubeconfig":"\/var\/run\/mosaic-kubernetes-external\/remote\/config"[^}]*"server":"https:\/\/bcm-head\.example\.com:11443"[^}]*"tlsServerName":"127\.0\.0\.1"/);
});

test("renders read-only Kubernetes RBAC including metrics without Secrets or pod execution", () => {
  const output = render("--show-only", "templates/rbac.yaml");
  assert.match(output, /apiGroups: \["metrics\.k8s\.io"\][\s\S]*resources: \["nodes", "pods"\][\s\S]*verbs: \["get", "list"\]/);
  assert.doesNotMatch(output, /resources: \[[^\]]*"secrets"/);
  assert.doesNotMatch(output, /resources: \[[^\]]*"pods\/exec"/);
  assert.doesNotMatch(output, /verbs: \[[^\]]*"(?:create|delete|patch|update)"/);
});

test("renders workload editor and pod exec RBAC for OpenClaw when edit mode is enabled", () => {
  const output = render(
    "--set",
    "modules.edit.enabled=true",
    "--set",
    "modules.terminal.enabled=true",
    "--show-only",
    "templates/rbac.yaml",
  );
  assert.match(output, /name: .*oc-editor/);
  assert.match(output, /resources: \["configmaps", "pods", "services"\]\s+verbs: \["create", "delete", "patch", "update"\]/);
  assert.match(output, /resources: \["pods\/exec"\]\s+verbs: \["create"\]/);
  assert.match(output, /resources: \["daemonsets", "deployments", "statefulsets"\]\s+verbs: \["create", "delete", "patch", "update"\]/);
  assert.match(output, /resources: \["cronjobs", "jobs"\]\s+verbs: \["create", "delete", "patch", "update"\]/);
  assert.doesNotMatch(output, /resources: \[[^\]]*"(?:secrets|clusterroles|customresourcedefinitions|serviceaccounts\/token)"/);
  const editorBinding = output.slice(output.lastIndexOf("kind: ClusterRoleBinding"));
  assert.match(editorBinding, /name: openclaw/);
  assert.doesNotMatch(editorBinding, /name: mosaic-terminal/);
});

test("binds an installer-supplied editor role without rendering a duplicate role", () => {
  const output = render(
    "--set",
    "modules.edit.enabled=true",
    "--set",
    "modules.edit.kubernetes.existingClusterRole=tenant-workload-editor",
    "--show-only",
    "templates/rbac.yaml",
  );
  assert.doesNotMatch(output, /kind: ClusterRole\s+metadata:\s+name: .*oc-editor/);
  assert.match(output, /kind: ClusterRoleBinding[\s\S]*name: tenant-workload-editor/);
});

test("seeds edit mode and approval settings into Kubernetes and BCM plugins", () => {
  const disabled = render("--show-only", "templates/openclaw-seed-configmap.yaml");
  const enabled = render(
    "--set",
    "modules.edit.enabled=true",
    "--set",
    "modules.edit.approvalTimeoutMs=45000",
    "--show-only",
    "templates/openclaw-seed-configmap.yaml",
  );
  assert.match(disabled, /"editEnabled": false/);
  assert.match(disabled, /^  mutation-ledger\.ts: \|-/m);
  assert.match(enabled, /"editEnabled": true/);
  assert.match(enabled, /"hitl": true/);
  assert.match(enabled, /"approvalTimeoutMs": 45000/);
  assert.match(enabled, /mutation-ledger\.ts: \|-/);
  assert.match(render("--show-only", "templates/openclaw.yaml"), /cp \/seed\/mutation-ledger\.ts \/home\/node\/\.openclaw\/extensions\/mutation-ledger\.ts/);
});

test("tells the assistant about session access modes only when editing is enabled", () => {
  const readonly = render();
  assert.match(readonly, /Edit mode is disabled/);
  assert.doesNotMatch(readonly, /Remote commands are permitted only/);

  const editable = render(
    "--set", "modules.edit.enabled=true",
    "--set", "modules.edit.ssh.enabled=true",
    "--set", "modules.edit.ssh.existingSecret=remote-ssh",
    "--set", "modules.edit.ssh.hosts[0].alias=worker-1",
    "--set", "modules.edit.ssh.hosts[0].address=10.0.0.7",
    "--set", "modules.edit.ssh.hosts[0].user=root",
    "--set", "modules.edit.ssh.hosts[0].port=22",
  );
  assert.match(editable, /## Session Access Modes/);
  assert.match(editable, /`ai_factory_operations_agent_access_mode`.*authoritative/);
  assert.match(editable, /call `run_remote_ssh`/);
  assert.match(editable, /For remote host operations, call `run_remote_ssh` immediately/);
});

test("renders an authenticated BCM admin path only for BCM edit mode", () => {
  const output = render(
    "--set",
    "modules.edit.enabled=true",
    "--set",
    "modules.edit.kubernetes.enabled=false",
    "--set",
    "modules.edit.bcm.enabled=true",
    "--set",
    "bcmMcp.enabled=true",
    "--set",
    "bcmMcp.mode=ssh-adapter",
    "--set",
    "bcmMcp.headHost=bcm-head",
    "--set",
    "bcmMcp.hostSshKeySecretName=bcm-host-ssh",
  );
  assert.match(output, /apiVersion: v1\s+kind: Secret[\s\S]*name: bcm-mcp-auth/);
  assert.doesNotMatch(output, /Apache-2\.0apiVersion/);
  assert.match(output, /name: MOSAIC_BCM_CMSH_ADMIN_ENABLED\s+value: "true"/);
  assert.match(output, /name: MOSAIC_BCM_MCP_TOKEN\s+valueFrom:\s+secretKeyRef:\s+name: bcm-mcp-auth\s+key: BCM_MCP_TOKEN/);
  assert.match(output, /"authToken": "\$\{MOSAIC_BCM_MCP_TOKEN\}"/);
  assert.match(output, /"editEnabled": true/);
  assert.match(output, /bcm_execute_cmsh_admin/);
  assert.doesNotMatch(output, /"authToken": "[A-Za-z0-9]{48}"/);
});

test("keeps the managed BCM adapter read-only when edit mode is disabled", () => {
  const output = render(
    "--set",
    "bcmMcp.enabled=true",
    "--set",
    "bcmMcp.mode=ssh-adapter",
    "--set",
    "bcmMcp.headHost=bcm-head",
    "--set",
    "bcmMcp.hostSshKeySecretName=bcm-host-ssh",
  );
  assert.match(output, /name: MOSAIC_BCM_CMSH_ADMIN_ENABLED\s+value: "false"/);
  assert.match(output, /name: MOSAIC_BCM_CMSH_USERNAME\s+value: "aichatbotuser"/);
  assert.match(output, /name: MOSAIC_BCM_CMSH_PROFILE\s+value: "readonly"/);
  assert.match(output, /"editEnabled": false/);
});

test("exposes edit and HITL state to the UI without changing their defaults", () => {
  const disabled = render("--show-only", "templates/mosaic-ui.yaml");
  const enabled = render(
    "--set",
    "modules.edit.enabled=true",
    "--show-only",
    "templates/mosaic-ui.yaml",
  );
  assert.match(disabled, /name: MOSAIC_EDIT_ENABLED\s+value: "false"/);
  assert.match(disabled, /name: MOSAIC_EDIT_HITL\s+value: "true"/);
  assert.match(enabled, /name: MOSAIC_EDIT_ENABLED\s+value: "true"/);
  assert.match(enabled, /name: MOSAIC_EDIT_HITL\s+value: "true"/);
  assert.match(enabled, /name: MOSAIC_SESSION_ACCESS_PLUGINS\s+value: "automation-guard,kubernetes"/);

  const ssh = render(
    "--set", "modules.edit.enabled=true",
    "--set", "modules.edit.kubernetes.enabled=false",
    "--set", "modules.edit.ssh.enabled=true",
    "--set", "modules.edit.ssh.existingSecret=ssh-key",
    "--set", "modules.edit.ssh.hosts[0].alias=node-a",
    "--set", "modules.edit.ssh.hosts[0].address=node-a",
    "--set", "modules.edit.ssh.hosts[0].user=tester",
    "--show-only", "templates/mosaic-ui.yaml",
  );
  assert.match(ssh, /name: MOSAIC_SESSION_ACCESS_PLUGINS\s+value: "automation-guard,kubernetes,remote-ssh"/);
});

test("validates edit mode dependencies and backend configuration", () => {
  const invalid = [
    ["modules.execution.enabled=false", /requires modules\.execution\.enabled=true/],
    ["modules.ui.enabled=false", /requires modules\.ui\.enabled=true or at least one openclaw\.slack\.editUserIds entry/],
    ["modules.edit.approvalTimeoutMs=999", /must be at least 1000/],
    ["modules.edit.kubernetes.enabled=false", /requires at least one configured edit backend/],
    ["modules.kubernetes.enabled=false", /requires modules\.kubernetes\.enabled=true/],
    ["modules.edit.bcm.enabled=true", "modules.bcm.enabled=false", /requires an enabled BCM MCP service/],
    ["modules.edit.kubernetes.enabled=false", "modules.edit.bcm.enabled=true", "bcmMcp.enabled=true", /requires bcmMcp\.mode=ssh-adapter/],
    ["modules.edit.ssh.enabled=true", /existingSecret is required/],
    ["modules.edit.ssh.enabled=true", "modules.edit.ssh.existingSecret=ssh-key", /hosts must contain at least one host/],
    ["modules.edit.ssh.enabled=true", "modules.edit.ssh.existingSecret=ssh-key", "modules.edit.ssh.hosts[0].alias=-bad", "modules.edit.ssh.hosts[0].address=node004", "modules.edit.ssh.hosts[0].user=root", /alias is invalid/],
  ];
  for (const entry of invalid) {
    const expected = entry.at(-1);
    const settings = entry.slice(0, -1);
    const args = ["template", "mosaic", chart, "--namespace", "mosaic-test", "--set", "modules.edit.enabled=true"];
    for (const setting of settings) args.push("--set", setting);
    const result = spawnSync("helm", args, { encoding: "utf8" });
    assert.notEqual(result.status, 0, settings.join(", "));
    assert.match(result.stderr, expected);
  }

  const fullAuto = spawnSync(
    "helm",
    [
      "template",
      "mosaic",
      chart,
      "--namespace",
      "mosaic-test",
      "--set",
      "modules.edit.enabled=true",
      "--set",
      "modules.edit.hitl=false",
      "--set",
      "modules.ui.enabled=false",
    ],
    { encoding: "utf8" },
  );
  assert.equal(fullAuto.status, 0, fullAuto.stderr);
});

test("renders constrained remote SSH only in the OpenClaw pod", () => {
  const settings = [
    "--set", "modules.edit.enabled=true",
    "--set", "modules.edit.kubernetes.enabled=false",
    "--set", "modules.edit.ssh.enabled=true",
    "--set", "modules.edit.ssh.existingSecret=remote-node-key",
    "--set", "modules.edit.ssh.hosts[0].alias=node004",
    "--set", "modules.edit.ssh.hosts[0].address=10.0.0.4",
    "--set", "modules.edit.ssh.hosts[0].user=root",
  ];
  const output = render(...settings, "--show-only", "templates/openclaw.yaml");
  const seed = render(...settings, "--show-only", "templates/openclaw-seed-configmap.yaml");
  assert.match(output, /name: init-remote-ssh-credentials/);
  assert.match(output, /name: init-remote-ssh-credentials[\s\S]*runAsNonRoot: true[\s\S]*runAsUser: 1000/);
  assert.doesNotMatch(output, /chown 1000:1000 \/credentials/);
  assert.match(output, /secretName: "remote-node-key"/);
  assert.match(output, /mountPath: \/var\/run\/mosaic-ssh\s+readOnly: true/);
  assert.match(output, /emptyDir:\s+medium: Memory/);
  assert.doesNotMatch(output, /mountPath: \/sandbox[\s\S]*remote-ssh/);
  for (const module of ["index", "policy", "runner"]) {
    assert.ok(seed.includes(`remote-ssh.${module}.ts: |-`));
    assert.ok(output.includes(`cp /seed/remote-ssh.${module}.ts /home/node/.openclaw/extensions/remote-ssh/${module}.ts`));
  }
  assert.match(seed, /"remote-ssh":\s*{\s*"enabled": true/);
  assert.match(seed, /"alias":"node004"/);
});

test("omits remote SSH credentials and plugin files by default", () => {
  const output = render("--show-only", "templates/openclaw.yaml");
  const seed = render("--show-only", "templates/openclaw-seed-configmap.yaml");
  assert.doesNotMatch(output, /remote-ssh-(?:source|credentials)/);
  assert.doesNotMatch(seed, /remote-ssh\.index\.ts/);
});

test("omits every terminal workload resource when the module is disabled", () => {
  const output = render();
  assert.doesNotMatch(output, /(?:name|app): mosaic-terminal(?:\s|$)/);
  assert.match(output, /name: MOSAIC_TERMINAL_ENABLED\s+value: "false"/);
});

test("renders the terminal service from the UI image with isolated read-only access", () => {
  const output = render("--set", "modules.terminal.enabled=true");
  const rbac = render("--set", "modules.terminal.enabled=true", "--show-only", "templates/rbac.yaml");
  assert.match(output, /kind: ServiceAccount[\s\S]*name: mosaic-terminal/);
  assert.match(output, /kind: Deployment[\s\S]*name: mosaic-terminal/);
  assert.match(output, /kind: Service[\s\S]*name: mosaic-terminal/);
  assert.match(output, /kind: Secret[\s\S]*name: mosaic-terminal-auth/);
  assert.match(output, /command: \["node", "\/app\/frontend\/bin\/mosaic-terminal\.mjs"\]/);
  assert.match(output, /name: PATH\s+value: \/opt\/node\/bin:\/tools:/);
  assert.match(output, /image: "[^"\s]+\/mosaic-ui:[^"]+"/);
  assert.match(output, /name: MOSAIC_TERMINAL_URL\s+value: "http:\/\/mosaic-terminal:3002"/);
  assert.match(output, /name: mosaic-terminal[\s\S]*namespace: mosaic-test[\s\S]*name: .*oc-reader/);
  assert.match(output, /requiredDuringSchedulingIgnoredDuringExecution:[\s\S]*app: openclaw/);
  assert.match(output, /curl -fsSL --retry 5 --retry-all-errors -o \/tools\/kubectl \\\s+"https:\/\/dl\.k8s\.io\/release\/v1\.34\.1\/bin\/linux\/\$architecture\/kubectl"/);
  assert.doesNotMatch(output, /registry\.k8s\.io\/kubectl/);
  assert.doesNotMatch(rbac, /resources: \[[^\]]*"secrets"/);
  assert.doesNotMatch(rbac, /resources: \[[^\]]*"pods\/exec"/);
  assert.doesNotMatch(rbac, /verbs: \[[^\]]*"(?:create|delete|patch|update)"/);
});

test("rejects terminal deployments without their required modules", () => {
  for (const disabled of ["modules.ui.enabled=false", "modules.execution.enabled=false", "modules.kubernetes.enabled=false"]) {
    const result = spawnSync(
      "helm",
      ["template", "mosaic", chart, "--namespace", "mosaic-test", "--set", "modules.terminal.enabled=true", "--set", disabled],
      { encoding: "utf8" },
    );
    assert.notEqual(result.status, 0, disabled);
    assert.match(result.stderr, /modules\.terminal\.enabled=true requires/);
  }
});

test("omits the cluster monitor when its module is disabled", () => {
  const output = render();
  assert.doesNotMatch(output, /(?:name|app): mosaic-cluster-monitor(?:\s|$)/);
  assert.match(output, /name: MOSAIC_CLUSTERS_ENABLED\s+value: "false"/);
});

test("renders a credential-isolated persistent cluster monitor from configured targets", () => {
  const output = render(
    "--set", "modules.clusters.enabled=true",
    "--set", "modules.slurm.enabled=false",
    "--set", "bcmMcp.enabled=true",
    "--set", "kubernetes.clusters[0].name=training",
    "--set", "kubernetes.clusters[0].displayName=Training Kubernetes",
    "--set", "kubernetes.clusters[0].kubeconfigSecretRef.name=training-kubeconfig",
    "--set", "kubernetes.clusters[0].kubeconfigSecretRef.key=config",
  );
  const monitor = render(
    "--set", "modules.clusters.enabled=true",
    "--show-only", "templates/mosaic-cluster-monitor.yaml",
  );
  assert.match(output, /kind: Deployment[\s\S]*name: mosaic-cluster-monitor/);
  assert.match(output, /kind: Service[\s\S]*name: mosaic-cluster-monitor/);
  assert.match(output, /kind: PersistentVolumeClaim[\s\S]*name: mosaic-cluster-monitor/);
  assert.match(output, /kind: Secret[\s\S]*name: mosaic-cluster-monitor-auth/);
  assert.match(output, /command: \["node", "\/app\/frontend\/bin\/mosaic-cluster-monitor\.mjs"\]/);
  assert.match(output, /image: "[^"\s]+\/mosaic-ui:[0-9a-f]{8}"/);
  assert.match(output, /automountServiceAccountToken: false/);
  assert.match(output, /name: MOSAIC_CLUSTERS_ENABLED\s+value: "true"/);
  assert.match(output, /name: MOSAIC_CLUSTER_MONITOR_URL\s+value: "http:\/\/mosaic-cluster-monitor:3003"/);
  assert.match(output, /MOSAIC_CLUSTER_TARGETS[\s\S]*BCM Cluster/);
  assert.match(output, /MOSAIC_CLUSTER_TARGETS[\s\S]*Local Kubernetes/);
  assert.match(output, /MOSAIC_CLUSTER_TARGETS[\s\S]*Training Kubernetes/);
  assert.match(output, /name: MOSAIC_CLUSTER_TIMEOUT_MS\s+value: "600000"/);
  assert.doesNotMatch(monitor, /automountServiceAccountToken: true/);
});

test("validates cluster monitor dependencies and configuration", () => {
  const invalid = [
    ["modules.ui.enabled=false", /requires modules\.ui\.enabled=true/],
    ["modules.execution.enabled=false", /requires modules\.execution\.enabled=true/],
    ["mosaicClusterMonitor.auth.create=false", /cluster monitor auth requires/],
    ["mosaicClusterMonitor.historyLimit=0", /historyLimit must be at least 1/],
    ["mosaicClusterMonitor.timeoutMs=1000", /timeoutMs must be between 5000 and 600000/],
    ["mosaicClusterMonitor.defaultIntervalHours=0", /must be between 1 and 8760/],
    ["mosaicClusterMonitor.kubernetes.enabled=false", /requires at least one configured BCM or Kubernetes target/],
  ];
  for (const [setting, expected] of invalid) {
    const result = spawnSync(
      "helm",
      ["template", "mosaic", chart, "--namespace", "mosaic-test", "--set", "modules.clusters.enabled=true", "--set", setting],
      { encoding: "utf8" },
    );
    assert.notEqual(result.status, 0, setting);
    assert.match(result.stderr, expected);
  }
});

test("installs a checksum-pinned upstream kubectl binary", () => {
  const output = render("--show-only", "templates/openclaw.yaml");
  assert.match(output, /https:\/\/dl\.k8s\.io\/release\/v1\.34\.1\/bin\/linux\/\$architecture\/kubectl/);
  assert.match(output, /7721f265e18709862655affba5343e85e1980639395d5754473dafaadcaa69e3/);
  assert.match(output, /420e6110e3ba7ee5a3927b5af868d18df17aae36b720529ffa4e9e945aa95450/);
  assert.doesNotMatch(output, /registry\.k8s\.io\/kubectl/);
});

test("packages every Kubernetes plugin module into the OpenClaw seed", () => {
  const seed = render("--show-only", "templates/openclaw-seed-configmap.yaml");
  const deployment = render("--show-only", "templates/openclaw.yaml");
  for (const module of ["index", "policy", "runner"]) {
    assert.ok(seed.includes(`kubernetes.${module}.ts: |-`));
    assert.ok(deployment.includes(`cp /seed/kubernetes.${module}.ts /home/node/.openclaw/extensions/kubernetes/${module}.ts`));
  }
});

test("creates the base workspace when every optional skill module is disabled", () => {
  const output = render(
    "--set", "modules.slurm.enabled=false",
    "--set", "modules.observability.enabled=false",
    "--set", "modules.bcm.enabled=false",
    "--show-only", "templates/openclaw.yaml",
  );
  assert.match(output, /mkdir -p \/home\/node\/\.openclaw\/tmp\/openclaw \/home\/node\/\.openclaw\/workspace\/skills/);
  assert.match(output, /cp \/seed\/AGENTS\.md \/home\/node\/\.openclaw\/workspace\/AGENTS\.md/);
});

test("initializes a fresh OpenClaw workspace before seeding it", () => {
  const output = render("--show-only", "templates/openclaw.yaml");
  assert.match(
    output,
    /mkdir -p \/home\/node\/\.openclaw\/tmp\/openclaw \/home\/node\/\.openclaw\/workspace[\s\S]*cp \/seed\/AGENTS\.md \/home\/node\/\.openclaw\/workspace\/AGENTS\.md/,
  );
});

test("preserves the Slurm evidence apiVersion after its SPDX header", () => {
  const output = render(
    "--show-only",
    "templates/slurm-evidence.yaml",
    "--set",
    "modules.slurm.enabled=true",
    "--set",
    "modules.bcm.enabled=false",
  );
  assert.match(output, /# SPDX-License-Identifier: Apache-2\.0\napiVersion: v1/);
  assert.doesNotMatch(output, /Apache-2\.0apiVersion/);
});

test("shares a generated credential between OpenClaw and the Slurm evidence collector", () => {
  const output = render(
    "--set", "modules.slurm.enabled=true",
    "--set", "modules.bcm.enabled=false",
  );
  assert.match(output, /kind: Secret\s+metadata:\s+name: slurm-evidence-auth/);
  assert.match(output, /name: EVIDENCE_AUTH_TOKEN\s+valueFrom:\s+secretKeyRef:\s+name: slurm-evidence-auth\s+key: token/);
  assert.match(output, /name: MOSAIC_SLURM_EVIDENCE_TOKEN\s+valueFrom:\s+secretKeyRef:\s+name: slurm-evidence-auth\s+key: token/);
});

test("rejects an unregistered default Kubernetes cluster", () => {
  const result = spawnSync(
    "helm",
    ["template", "mosaic", chart, "--namespace", "mosaic-test", "--set", "kubernetes.defaultCluster=missing"],
    { encoding: "utf8" },
  );
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /defaultCluster "missing" is not registered/);
});


test("preloads selected skill instructions from their authoritative files", () => {
  for (const skill of ["gpu-networking", "slurm"]) {
    const output = render("--show-only", "templates/openclaw-seed-configmap.yaml", "--set", `openclaw.bootstrapSkills[0]=${skill}`);
    const instructions = configMapBlock(output, "AGENTS.md");
    const source = readFileSync(new URL(`../files/openclaw-seed/skills/${skill}/SKILL.md`, import.meta.url), "utf8").trim();
    assert.ok(instructions.includes(source));
    const references = new URL(`../files/openclaw-seed/skills/${skill}/references/`, import.meta.url);
    for (const name of existsSync(references) ? readdirSync(references).filter(name => name.endsWith(".md")) : []) {
      assert.ok(instructions.includes(readFileSync(new URL(name, references), "utf8").trim()));
    }
    const config = JSON.parse(configMapBlock(output, "openclaw.json"));
    assert.ok(config.agents.defaults.bootstrapMaxChars > instructions.length);
  }
});

test("packaged GPU documentation installs locally with research and UI disabled", () => {
  const directory = mkdtempSync(join(tmpdir(), "skill-offline-"));
  try {
    execFileSync("helm", ["package", chart, "--destination", directory]);
    const archive = join(directory, readdirSync(directory).find(name => name.endsWith(".tgz")));
    const output = execFileSync("helm", ["template", "offline", archive,
      "--set", "modules.research.enabled=false", "--set", "modules.kubernetes.enabled=false",
      "--set", "modules.slurm.enabled=false", "--set", "modules.bcm.enabled=false",
      "--set", "modules.diagnostics.enabled=false", "--set", "modules.observability.enabled=false",
      "--set", "modules.ui.enabled=false"], {encoding: "utf8"});
    const seed = join(directory, "seed");
    const home = join(directory, "home");
    execFileSync("mkdir", ["-p", seed, home]);
    const seedSection = output.split("name: openclaw-seed\n")[1].split("\n---")[0];
    for (const line of seedSection.split("\n")) {
      if (line.startsWith("  ") && !line.startsWith("   ") && line.endsWith(": |-")) {
        const key = line.trim().slice(0, -4);
        writeFileSync(join(seed, key), configMapBlock(seedSection, key));
      }
    }
    const init = output.split("- name: init-config\n")[1].split("          securityContext:")[0];
    const script = init.split("            - |\n")[1].split("\n")
      .map(line => line.slice(14)).join("\n")
      .replaceAll("/home/node/.openclaw", home).replaceAll("/seed/", `${seed}/`);
    execFileSync("sh", ["-eu", "-c", script]);
    const relative = "skills/gpu-networking";
    const workspace = join(home, "workspace");
    const references = join(workspace, relative, "references");
    const paths = [`${relative}/SKILL.md`, ...readdirSync(references).map(name => `${relative}/references/${name}`)];
    for (const path of paths) {
      const content = readFileSync(join(workspace, path), "utf8");
      assert.ok(content.trim().length, path);
      assert.equal(content.includes("https://") || content.includes("http://"), false, path);
      for (const target of content.split("`").filter((_, index) => index % 2 === 1)) {
        if (target.startsWith("skills/")) assert.ok(existsSync(join(workspace, target)), `${path}: ${target}`);
      }
    }
  } finally {
    rmSync(directory, {recursive: true, force: true});
  }
});

test("workspace and audit storage use the cluster default unless overridden", () => {
  const defaults = render("--show-only", "templates/pvcs.yaml");
  assert.doesNotMatch(defaults, /^\s*storageClassName:/m);
  const configured = render(
    "--show-only", "templates/pvcs.yaml",
    "--set", "openclaw.pvc.storageClassName=workspace-tier",
    "--set", "mosaicUi.auditPvc.storageClassName=audit-tier",
  );
  assert.match(configured, /storageClassName: "workspace-tier"/);
  assert.match(configured, /storageClassName: "audit-tier"/);
});

test("configures optional Loki access without exposing its credential to UI or sandbox", () => {
  const args = ["--set", "modules.observability.enabled=true", "--set", "observability.loki.url=https://logs.example.com", "--set", "observability.loki.tenantId=operations", "--set", "observability.loki.auth.existingSecret=logs-readonly"];
  const seed = render(...args, "--show-only", "templates/openclaw-seed-configmap.yaml");
  const runtime = render(...args, "--show-only", "templates/openclaw.yaml");
  const ui = render(...args, "--show-only", "templates/mosaic-ui.yaml");
  assert.match(seed, /"lokiUrl": "https:\/\/logs.example.com"/);
  assert.match(seed, /"lokiTenantId": "operations"/);
  assert.match(seed, /observability\.loki\.ts:/);
  assert.match(runtime, /cp \/seed\/observability.loki.ts/);
  assert.match(runtime, /name: MOSAIC_LOKI_AUTHORIZATION\s+valueFrom:\s+secretKeyRef:\s+name: "logs-readonly"\s+key: "authorization"/);
  assert.doesNotMatch(ui, /logs-readonly|MOSAIC_LOKI_AUTHORIZATION/);
  const disabled = render(...args, "--set", "modules.observability.enabled=false", "--show-only", "templates/openclaw.yaml");
  assert.doesNotMatch(disabled, /name: MOSAIC_LOKI_AUTHORIZATION/);
  const defaults = render("--show-only", "templates/openclaw.yaml");
  assert.doesNotMatch(defaults, /name: MOSAIC_LOKI_AUTHORIZATION/);
});


test("external inference can trust a site CA with or without the compatibility proxy", () => {
  for (const enabled of [true, false]) {
    const output = render("--set", `llm.mode=external,llm.external.baseUrl=https://inference.example.com/v1,llm.external.model=test-model,llm.requestCompatibility.enabled=${enabled},llm.external.caCertificateSecret=site-ca,llm.external.caCertificateKey=root.pem`);
    const expectedConsumers = enabled ? 2 : 1;
    assert.equal([...output.matchAll(/name: NODE_EXTRA_CA_CERTS/g)].length, expectedConsumers);
    assert.equal([...output.matchAll(/mountPath: \/etc\/llm-ca/g)].length, expectedConsumers);
    assert.equal([...output.matchAll(/secretName: "site-ca"/g)].length, expectedConsumers);
    assert.equal([...output.matchAll(/key: "root.pem"/g)].length, expectedConsumers);
    assert.doesNotMatch(output, /NODE_TLS_REJECT_UNAUTHORIZED/);
  }
  assert.doesNotMatch(render("--set", "llm.mode=external,llm.external.baseUrl=https://inference.example.com/v1,llm.external.model=test-model"), /NODE_EXTRA_CA_CERTS/);
  assert.doesNotMatch(render("--set", "llm.external.caCertificateSecret=site-ca"), /NODE_EXTRA_CA_CERTS/);
});

test("configures a tenant-scoped VictoriaMetrics backend and native Grafana datasource", () => {
  const endpoint = "http://vmselect.metrics.svc:8481/select/17/prometheus";
  const args = ["--set-string", `observability.prometheusUrl=${endpoint}`,
    "--set-string", "observability.grafanaDatasourceUid=vm-metrics",
    "--set-string", "observability.grafanaDatasourceType=victoriametrics-metrics-datasource"];
  const seed = render(...args, "--show-only", "templates/openclaw-seed-configmap.yaml");
  const config = JSON.parse(configMapBlock(seed, "openclaw.json"));
  for (const name of ["observability", "grafana"]) {
    assert.equal(config.plugins.entries[name].config.prometheusUrl, endpoint);
    assert.equal(config.plugins.entries[name].config.datasourceUid, "vm-metrics");
    assert.equal(config.plugins.entries[name].config.datasourceType, "victoriametrics-metrics-datasource");
  }
  for (const template of ["templates/openclaw.yaml", "templates/mosaic-ui.yaml"]) {
    assert.ok(render(...args, "--show-only", template).includes(endpoint));
  }
});

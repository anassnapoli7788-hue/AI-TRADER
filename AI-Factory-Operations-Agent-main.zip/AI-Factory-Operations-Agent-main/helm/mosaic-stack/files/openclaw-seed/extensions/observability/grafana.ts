// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

declare const Buffer: { from(value: string): { toString(encoding: string): string } };

type PanelSpec = {
  title: string;
  query: string;
  datasource?: { type: "prometheus" | "victoriametrics-metrics-datasource" | "loki"; uid: string };
  unit?: string;
  visualization?: "timeseries" | "stat" | "gauge" | "table" | "logs";
  legend?: string;
  description?: string;
};

type ValidationIssue = {
  panelTitle: string;
  query: string;
  severity: "error" | "warning";
  message: string;
};

const DEFAULT_UI_URL = "http://mosaic-ui:3000";
const GRAFANA_PROXY_PREFIX = "/api/grafana/proxy";

function resolveString(pluginConfig: unknown, key: string, fallback?: string) {
  if (
    pluginConfig &&
    typeof pluginConfig === "object" &&
    key in pluginConfig &&
    typeof (pluginConfig as Record<string, unknown>)[key] === "string"
  ) {
    const value = String((pluginConfig as Record<string, unknown>)[key] || "").trim();
    if (value) return value.replace(/\/+$/, "");
  }
  if (fallback) return fallback;
  throw new Error(`observability.${key} is required`);
}

function jsonToolResult(payload: unknown) {
  return {
    content: [{ type: "text", text: JSON.stringify(payload, null, 2) }],
    details: payload,
  };
}

function stringArrayConfig(pluginConfig: unknown, key: string) {
  if (!pluginConfig || typeof pluginConfig !== "object") {
    return [];
  }
  const raw = (pluginConfig as Record<string, unknown>)[key];
  return Array.isArray(raw)
    ? raw.map((value) => (typeof value === "string" ? value.trim() : "")).filter(Boolean)
    : [];
}

function isToolEnabled(pluginConfig: unknown, name: string) {
  const enabledTools = new Set(stringArrayConfig(pluginConfig, "enabledTools"));
  if (enabledTools.size > 0 && !enabledTools.has(name)) {
    return false;
  }
  return !new Set(stringArrayConfig(pluginConfig, "disabledTools")).has(name);
}

function stringParam(value: unknown) {
  return typeof value === "string" && value.trim() ? value.trim() : undefined;
}

function numberParam(value: unknown, fallback: number) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function boolParam(value: unknown, fallback: boolean) {
  return typeof value === "boolean" ? value : fallback;
}

function boolConfig(pluginConfig: unknown, key: string, fallback: boolean) {
  if (!pluginConfig || typeof pluginConfig !== "object") return fallback;
  const value = (pluginConfig as Record<string, unknown>)[key];
  return typeof value === "boolean" ? value : fallback;
}

function normalizePanel(raw: unknown, index: number): PanelSpec | null {
  if (!raw || typeof raw !== "object") return null;
  const value = raw as Record<string, unknown>;
  const query = stringParam(value.query);
  if (!query) return null;
  const datasource = value.datasource as PanelSpec["datasource"];
  return {
    datasource,
    title: stringParam(value.title) || `Panel ${index + 1}`,
    query,
    unit: stringParam(value.unit),
    visualization: (stringParam(value.visualization) as PanelSpec["visualization"]) || "timeseries",
    legend: stringParam(value.legend),
    description: stringParam(value.description),
  };
}

function panelsFromParams(rawParams: Record<string, unknown>) {
  return Array.isArray(rawParams.panels)
    ? rawParams.panels.map(normalizePanel).filter((panel): panel is PanelSpec => Boolean(panel))
    : [];
}

async function fetchJson(url: string, options?: RequestInit) {
  const response = await fetch(url, options);
  const text = await response.text();
  let payload: unknown;
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    payload = { raw: text };
  }
  if (!response.ok) {
    throw new Error(`HTTP ${response.status} from ${url}: ${JSON.stringify(payload).slice(0, 1000)}`);
  }
  return payload as Record<string, unknown>;
}

function buildGrafanaQueryPayload(panel: PanelSpec, rangeMinutes: number, defaultDatasource: NonNullable<PanelSpec["datasource"]>) {
  return {
    queries: [
      {
        refId: "A",
        datasource: panel.datasource || defaultDatasource,
        expr: panel.query,
        ...(panel.datasource?.type === "loki" ? {queryType: "range", maxLines: 1000} : {}),
        range: true,
        instant: false,
        intervalMs: 15000,
        maxDataPoints: 600,
      },
    ],
    from: `now-${Math.max(1, Math.trunc(rangeMinutes))}m`,
    to: "now",
  };
}

function grafanaFrameCount(payload: Record<string, unknown>) {
  const results = payload.results as Record<string, unknown> | undefined;
  const first = results?.A as Record<string, unknown> | undefined;
  if (first?.error) throw new Error(String(first.error));
  const frames = Array.isArray(first?.frames) ? first.frames : [];
  return frames.filter((frame: any) => frame.data?.values?.some((values: unknown[]) => values.length > 0)).length;
}

function authHeaders(pluginConfig: unknown) {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  const token = stringParam((pluginConfig as Record<string, unknown> | undefined)?.token);
  const user = stringParam((pluginConfig as Record<string, unknown> | undefined)?.basicUser);
  const password = stringParam((pluginConfig as Record<string, unknown> | undefined)?.basicPassword);
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  } else if (user && password) {
    headers.Authorization = `Basic ${Buffer.from(`${user}:${password}`).toString("base64")}`;
  }
  return headers;
}

function uiAuthHeaders() {
  const token = process.env.MOSAIC_UI_MACHINE_TOKEN || "";
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function validatePanels(
  prometheusUrl: string,
  grafanaUrl: string,
  uiUrl: string,
  headers: Record<string, string>,
  defaultDatasource: NonNullable<PanelSpec["datasource"]>,
  panels: PanelSpec[],
  requireData: boolean,
  rangeMinutes: number,
) {
  const issues: ValidationIssue[] = [];
  const results: Array<{ title: string; query: string; seriesCount: number; grafanaFrameCount: number; sample?: unknown }> = [];

  const datasources = await fetchJson(`${grafanaUrl}/api/datasources`, {headers}) as unknown as Array<{uid: string; type: string; name: string}>;
  for (const panel of panels) {
    const selected = panel.datasource || defaultDatasource;
    if (!["prometheus", "victoriametrics-metrics-datasource", "loki"].includes(selected.type) || !datasources.some(source => source.uid === selected.uid && source.type === selected.type)) {
      issues.push({panelTitle: panel.title, query: panel.query, severity: "error", message: "Panel datasource UID or type is missing or unavailable. Select the intended datasource from availableDatasources and retry."});
      continue;
    }
    if (panel.visualization === "logs" && selected.type !== "loki") {
      issues.push({panelTitle: panel.title, query: panel.query, severity: "error", message: "Log panels require a Loki datasource. Select one from availableDatasources."});
      continue;
    }
    const url = new URL(`${prometheusUrl}/api/v1/query`);
    url.searchParams.set("query", panel.query);
    try {
      const payload = selected.type !== "loki" ? await fetchJson(url.toString()) : {};
      const data = payload.data as { result?: unknown[] } | undefined;
      const result = Array.isArray(data?.result) ? data.result : [];
      if (requireData && selected.type !== "loki" && result.length === 0) {
        issues.push({
          panelTitle: panel.title,
          query: panel.query,
          severity: "error",
          message: "Query is valid but returned no series. Adjust the metric name, labels, or time window.",
        });
      }
      let frameCount = 0;
      try {
        const grafanaPayload = await fetchJson(`${grafanaUrl}/api/ds/query`, {
          method: "POST",
          headers,
          body: JSON.stringify(buildGrafanaQueryPayload(panel, rangeMinutes, defaultDatasource)),
        });
        frameCount = grafanaFrameCount(grafanaPayload);
        if (requireData && frameCount === 0) {
          issues.push({
            panelTitle: panel.title,
            query: panel.query,
            severity: "error",
            message: "Grafana datasource query returned no data frames. The panel would render empty.",
          });
        }
      } catch (error) {
        issues.push({
          panelTitle: panel.title,
          query: panel.query,
          severity: "error",
          message: `Grafana datasource validation failed: ${error instanceof Error ? error.message : String(error)}`,
        });
      }
      try {
        const uiProxyPayload = await fetchJson(`${uiUrl}/api/grafana/proxy/api/ds/query`, {
          method: "POST",
          headers: { ...uiAuthHeaders(), Origin: uiUrl },
          body: JSON.stringify(buildGrafanaQueryPayload(panel, rangeMinutes, defaultDatasource)),
        });
        const uiFrameCount = grafanaFrameCount(uiProxyPayload);
        if (requireData && uiFrameCount === 0) {
          issues.push({
            panelTitle: panel.title,
            query: panel.query,
            severity: "error",
            message: "The frontend Grafana proxy returned no data frames. The iframe panel would render empty.",
          });
        }
      } catch (error) {
        issues.push({
          panelTitle: panel.title,
          query: panel.query,
          severity: "error",
          message: `Frontend Grafana proxy validation failed: ${error instanceof Error ? error.message : String(error)}`,
        });
      }
      results.push({ title: panel.title, query: panel.query, seriesCount: result.length, grafanaFrameCount: frameCount, sample: result[0] });
    } catch (error) {
      issues.push({
        panelTitle: panel.title,
        query: panel.query,
        severity: "error",
        message: error instanceof Error ? error.message : String(error),
      });
    }
  }

  return {
    ok: issues.filter((issue) => issue.severity === "error").length === 0,
    issues,
    results,
    availableDatasources: datasources.map(({uid, type, name}) => ({uid, type, name})),
  };
}

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80) || "mosaic-dashboard";
}

function pathFromGrafanaUrl(value: string) {
  if (!value) return "/";
  if (value.startsWith("http://") || value.startsWith("https://")) {
    const parsed = new URL(value);
    return `${parsed.pathname}${parsed.search}`;
  }
  return value.startsWith("/") ? value : `/${value}`;
}

function ensureGrafanaSubPath(path: string, grafanaUrl: string) {
  if (path.startsWith(GRAFANA_PROXY_PREFIX)) return path;
  const pathname = new URL(grafanaUrl).pathname;
  const base = pathname.endsWith("/") ? pathname.slice(0, -1) : pathname;
  const relative = base && path.startsWith(`${base}/`) ? path.slice(base.length) : path;
  return `${GRAFANA_PROXY_PREFIX}${relative}`;
}

function appendTimeRange(path: string, rangeMinutes: number) {
  const separator = path.includes("?") ? "&" : "?";
  return `${path}${separator}orgId=1&from=now-${Math.trunc(rangeMinutes)}m&to=now&kiosk`;
}

function buildPanel(panel: PanelSpec, index: number, defaultDatasource: NonNullable<PanelSpec["datasource"]>) {
  const type = panel.visualization || "timeseries";
  const width = type === "stat" || type === "gauge" ? 6 : 12;
  return {
    id: index + 1,
    type,
    title: panel.title,
    description: panel.description,
    datasource: panel.datasource || defaultDatasource,
    gridPos: {
      h: type === "stat" || type === "gauge" ? 6 : 8,
      w: width,
      x: (index % Math.floor(24 / width)) * width,
      y: Math.floor(index / Math.floor(24 / width)) * 8,
    },
    targets: [
      {
        refId: "A",
        expr: panel.query,
        ...(panel.datasource?.type === "loki" ? {queryType: "range", maxLines: 1000} : {}),
        range: true,
        legendFormat: panel.legend || "",
      },
    ],
    fieldConfig: {
      defaults: {
        unit: panel.unit || "none",
      },
      overrides: [],
    },
    options: {
      legend: { displayMode: "list", placement: "bottom" },
      tooltip: { mode: "multi", sort: "none" },
    },
  };
}

function buildDashboard(title: string, panels: PanelSpec[], defaultDatasource: NonNullable<PanelSpec["datasource"]>, rangeMinutes: number) {
  return {
    id: null,
    uid: `mosaic-${Date.now().toString(36)}`,
    title,
    tags: ["mosaic", "openclaw-generated"],
    timezone: "browser",
    schemaVersion: 42,
    version: 0,
    refresh: "15s",
    time: {
      from: `now-${Math.max(1, Math.trunc(rangeMinutes))}m`,
      to: "now",
    },
    panels: panels.map((panel, index) => buildPanel(panel, index, defaultDatasource)),
  };
}

type PluginApi = { pluginConfig: unknown; registerTool(tool: any): void };

export function registerGrafanaTools(api: PluginApi) {
    if (!boolConfig(api.pluginConfig, "grafanaEnabled", true)) return;
    const grafanaUrl = resolveString(api.pluginConfig, "grafanaUrl");
    const prometheusUrl = resolveString(api.pluginConfig, "prometheusUrl");
    const uiUrl = resolveString(api.pluginConfig, "uiUrl", DEFAULT_UI_URL);
    const datasourceUid = resolveString(api.pluginConfig, "datasourceUid");
    const defaultDatasource = {
      uid: datasourceUid,
      type: resolveString(api.pluginConfig, "datasourceType", "prometheus") as NonNullable<PanelSpec["datasource"]>["type"],
    };
    const headers = authHeaders(api.pluginConfig);
    const registerTool = (tool: Parameters<typeof api.registerTool>[0]) => {
      if (isToolEnabled(api.pluginConfig, tool.name)) {
        api.registerTool(tool);
      }
    };

    registerTool({
      name: "dashboard_list",
      label: "List Dashboards",
      description: "Discover Grafana datasource names, types, and UIDs and search existing dashboards. Datasources are returned even when no dashboards match.",
      parameters: {
        type: "object",
        additionalProperties: false,
        properties: {
          query: { type: "string", description: "Optional dashboard title search string." },
          limit: { type: "number", description: "Maximum dashboards to return. Default 50." },
        },
      },
      async execute(_toolCallId: string, rawParams: Record<string, unknown>) {
        const url = new URL(`${grafanaUrl}/api/search`);
        url.searchParams.set("type", "dash-db");
        url.searchParams.set("limit", String(Math.max(1, Math.min(500, numberParam(rawParams.limit, 50)))));
        const query = stringParam(rawParams.query);
        if (query) url.searchParams.set("query", query);
        return jsonToolResult({ grafanaUrl, datasources: await fetchJson(`${grafanaUrl}/api/datasources`, {headers}), dashboards: await fetchJson(url.toString(), { headers }) });
      },
    });

    registerTool({
      name: "dashboard_create",
      label: "Create Dashboard",
      description: "Create a Grafana dashboard after validating every Prometheus, VictoriaMetrics or Loki panel query, then open it in the UI Grafana tab.",
      parameters: {
        type: "object",
        additionalProperties: false,
        properties: {
          title: { type: "string", description: "Dashboard title." },
          panels: {
            type: "array",
            description: "Panel specs: title, query (PromQL, MetricsQL or LogQL), datasource {type: prometheus, victoriametrics-metrics-datasource or loki, uid: discovered Grafana UID}, visualization (timeseries, stat, gauge, table, logs), optional unit/legend/description. Omit datasource only to use the configured metrics default.",
            items: { type: "object" },
          },
          rangeMinutes: { type: "number", description: "Dashboard time range in minutes. Default 60." },
          requireData: { type: "boolean", description: "If true, do not create when any query returns no data. Default true." },
          openInUi: { type: "boolean", description: "If true, switch the UI to Grafana after creation. Default true." },
        },
      },
      async execute(_toolCallId: string, rawParams: Record<string, unknown>) {
        const title = stringParam(rawParams.title) || "Generated Dashboard";
        const panels = panelsFromParams(rawParams);
        if (panels.length === 0) {
          throw new Error("Provide panels with explicit PromQL, MetricsQL or LogQL queries.");
        }

        const requireData = boolParam(rawParams.requireData, true);
        const rangeMinutes = Math.max(1, Math.min(10080, numberParam(rawParams.rangeMinutes, 60)));
        const validation = await validatePanels(prometheusUrl, grafanaUrl, uiUrl, headers, defaultDatasource, panels, requireData, rangeMinutes);
        if (!validation.ok) {
          return jsonToolResult({
            created: false,
            reason: "Dashboard validation failed. Fix the panel queries and call dashboard_create again.",
            validation,
          });
        }

        const dashboard = buildDashboard(title, panels, defaultDatasource, rangeMinutes);
        const createPayload = await fetchJson(`${grafanaUrl}/api/dashboards/db`, {
          method: "POST",
          headers,
          body: JSON.stringify({ dashboard, folderId: 0, overwrite: true, message: "Created by OpenClaw dashboard plugin" }),
        });

        const uid = stringParam(createPayload.uid) || stringParam((dashboard as Record<string, unknown>).uid) || "";
        const url = stringParam(createPayload.url) || `/d/${uid}/${slugify(title)}`;
        const grafanaPath = ensureGrafanaSubPath(pathFromGrafanaUrl(url), grafanaUrl);
        const iframeUrl = appendTimeRange(grafanaPath, rangeMinutes);
        const dashboardUrl = `${grafanaUrl}${grafanaPath.slice(GRAFANA_PROXY_PREFIX.length)}`;
        let uiNotification: unknown = null;

        if (boolParam(rawParams.openInUi, true)) {
          try {
            uiNotification = await fetchJson(`${uiUrl}/api/ui/actions`, {
              method: "POST",
              headers: uiAuthHeaders(),
              body: JSON.stringify({
                type: "open_grafana",
                title,
                iframeUrl,
                dashboardUid: uid,
                dashboardUrl,
              }),
            });
          } catch (error) {
            uiNotification = { error: error instanceof Error ? error.message : String(error) };
          }
        }

        return jsonToolResult({
          created: true,
          title,
          uid,
          grafanaUrl,
          dashboardUrl,
          iframeUrl,
          validation,
          uiNotification,
        });
      },
    });

    registerTool({
      name: "dashboard_open",
      label: "Open Dashboard",
      description: "Open an existing Grafana dashboard UID in the UI Grafana tab.",
      parameters: {
        type: "object",
        additionalProperties: false,
        required: ["uid"],
        properties: {
          uid: { type: "string", description: "Grafana dashboard UID." },
          title: { type: "string", description: "Dashboard title." },
          rangeMinutes: { type: "number", description: "Dashboard lookback in minutes. Default 60." },
        },
      },
      async execute(_toolCallId: string, rawParams: Record<string, unknown>) {
        const uid = stringParam(rawParams.uid);
        if (!uid) throw new Error("uid is required");
        const title = stringParam(rawParams.title) || uid;
        const rangeMinutes = Math.max(1, Math.min(10080, numberParam(rawParams.rangeMinutes, 60)));
        const path = ensureGrafanaSubPath(`/d/${uid}/${slugify(title)}`, grafanaUrl);
        const iframeUrl = appendTimeRange(path, rangeMinutes);
        const uiNotification = await fetchJson(`${uiUrl}/api/ui/actions`, {
          method: "POST",
          headers: uiAuthHeaders(),
          body: JSON.stringify({
            type: "open_grafana",
            title,
            iframeUrl,
            dashboardUid: uid,
            dashboardUrl: `${grafanaUrl}${path.slice(GRAFANA_PROXY_PREFIX.length)}`,
          }),
        });
        return jsonToolResult({ opened: true, uid, iframeUrl, uiNotification });
      },
    });
}

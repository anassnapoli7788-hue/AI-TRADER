#!/bin/bash
# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Define variables
INGRESS_NAME="simple-ingress"

# Function to get the hostname from the Ingress
get_ingress_hostname() {
    hostname=$(kubectl get ingress $INGRESS_NAME -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
    echo $hostname
}

# Main loop to wait for the hostname
while true; do
    echo "Checking for hostname in Ingress $INGRESS_NAME..."
    hostname=$(get_ingress_hostname)

    if [[ -n "$hostname" ]]; then
        echo "Hostname found: $hostname"
        break
    else
        echo "Hostname not yet available. Waiting for 30 seconds..."
        sleep 30
    fi
done

echo "Ingress is ready with hostname: $hostname"
